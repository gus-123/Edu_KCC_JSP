package kosa.dao;

import kosa.model.Board;

public class BoardDao { //dao에 있는 메소드를 호출
    private static BoardDao dao = new BoardDao(); // 싱글톤 형식으로 생성 (BoardDao를 여러번 부르지 않기 위해서)

    public static BoardDao getInstance() { // 객체를 전달하여 받기위함.
        return dao;
    }

    public void insert(Board board) {
        System.out.println(board);
    }
}
