package kosa.servlet;

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/HelloServlet")
//@WebServlet({"/HelloServlet", "/hello"}) => 배열형식으로도 요청 가능하다

public class HelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public HelloServlet() {
        super();
    }


    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        // => response에 연결되어 클라이언트에게 전달된다.
        out.println("<html><head><title>hello</title></head>");
        out.println("<body>");
        out.println("<h1>Hello Servelt</h1>");
        out.println("</body>");
        out.println("</html>");

        out.close();



//      response.getWriter().append("Served at: ").append(request.getContextPath());
        //클라이언트가 원하는 서비스 제공 내용
//      System.out.println("호출됨!!");
    }

}