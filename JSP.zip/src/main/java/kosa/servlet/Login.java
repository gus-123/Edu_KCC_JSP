package kosa.servlet;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/Login")
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        request.setAttribute("username", username);
        request.setAttribute("password", password);
        request.setAttribute("email", email);

        //페이지이동
        //1. Dispatcher : 기존 요청의 연장선(1개의 request)
        RequestDispatcher re = request.getRequestDispatcher("/login.jsp");
        re.forward(request, response);
    }
}