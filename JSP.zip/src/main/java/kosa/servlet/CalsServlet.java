package kosa.servlet;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/CalsServlet")
public class CalsServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        //요청과 관련된 정보를 담고 있는 것 : request
        int num1 = Integer.parseInt(request.getParameter("num1"));
        int num2 = Integer.parseInt(request.getParameter("num2"));
        String name = request.getParameter("name");

        int result = num1 + num2;
        request.setAttribute("result", result);  // 요청하는 페이지안에 배달되도록 request객체에 넣어줌(데이터 값을 key, value 형태로 저장)
        request.setAttribute("name", name);


        //페이지이동
        //1. Dispatcher : 기존 요청의 연장선(1개의 request)
        RequestDispatcher re = request.getRequestDispatcher("/result.jsp");
        re.forward(request, response);

        //2. Redirect : 기존 요청과 다른 새로운 요청으로 이동 (http 매서드 300번대)
        //response.sendRedirect("result.jsp");
    }
}